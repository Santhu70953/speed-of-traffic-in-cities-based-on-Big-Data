# Tableau Dashboards

## Overview
This directory contains Tableau workbooks for visualizing Big Data pipeline results and analytics.

## Dashboards

### Dashboard 1
- **File**: `dashboard_1.twb`
- **Purpose**: Data Ingestion Overview and Pipeline Metrics
- **Key Metrics**:
  - Records Processed
  - Data Quality Score
  - Ingestion Time
  - Source Distribution

### Dashboard 2
- **File**: `dashboard2.twb`
- **Purpose**: Feature Engineering Analysis
- **Key Metrics**:
  - Feature Correlation Matrix
  - Missing Value Analysis
  - Distribution of Features
  - Outlier Detection Results

### Dashboard 3
- **File**: `dashboard_3.twb`
- **Purpose**: Model Training Performance
- **Key Metrics**:
  - Training Loss Over Epochs
  - Validation Accuracy
  - Cross-Validation Scores
  - Hyperparameter Tuning Results

### Dashboard 4
- **File**: `dashboard4.twb`
- **Purpose**: Model Evaluation and Prediction Results
- **Key Metrics**:
  - ROC Curve
  - Confusion Matrix
  - Precision-Recall Curve
  - Feature Importance

## Connection Setup

1. Connect to your data source (e.g., SQL Server, PostgreSQL, Spark)
2. Configure the data connection in Tableau
3. Refresh data sources regularly

## Requirements
- Tableau Desktop 2021 or later
- Access to the project data warehouse
- Required credentials for data source connections

## Data Refresh Schedule
- Dashboards refresh automatically every 6 hours
- Manual refresh available on-demand
- Last updated: Check dashboard footer for timestamp
