# Big Data Pipeline Project

## Project Overview
This is a comprehensive Big Data analytics pipeline built with Apache Spark, PySpark, and Python. It covers the complete machine learning workflow from data ingestion to model evaluation.

## Project Structure

```
project/
├── notebooks/
│   ├── 1_data_ingestion.ipynb          # Data loading and preprocessing
│   ├── 2_feature_engineering.ipynb     # Feature creation and transformation
│   ├── 3_model_training.ipynb          # ML model training and tuning
│   └── 4_evaluation.ipynb              # Model evaluation and metrics
├── tableau/
│   ├── dashboard_1.twb                 # Ingestion Metrics Dashboard
│   ├── dashboard2.twb                  # Feature Engineering Dashboard
│   ├── dashboard_3.twb                 # Model Training Dashboard
│   ├── dashboard4.twb                  # Evaluation Dashboard
│   └── README_tableau.md               # Tableau documentation
├── scripts/
│   ├── setup_environment.sh            # Environment setup script
│   ├── run_pipeline.py                 # Main pipeline orchestration
│   └── performance_profiler.py         # Performance monitoring
├── config/
│   ├── spark_config.yaml               # Spark configuration
│   └── tableau_config.json             # Tableau connection config
├── data/
│   ├── schemas/                        # Data schema definitions
│   └── samples/                        # Sample datasets
├── tests/
│   └── test_pipeline.py                # Unit tests
├── environment.yml                     # Conda dependencies
├── Dockerfile                          # Container configuration
└── README.md                           # This file
```

## Key Features

- **Distributed Computing**: Apache Spark for scalable data processing
- **Feature Engineering**: Advanced techniques for feature transformation
- **Machine Learning**: Regression and classification models
- **Data Visualization**: Tableau dashboards for insights
- **Performance Profiling**: Real-time performance monitoring
- **Containerization**: Docker support for deployment

## Prerequisites

- Python 3.9 or higher
- Apache Spark 3.0 or higher
- Java 8 or higher
- Docker (optional, for containerized deployment)
- Tableau (optional, for dashboard viewing)

## Installation

### 1. Clone the Repository
```bash
git clone <repository-url>
cd project
```

### 2. Set Up Environment
```bash
bash scripts/setup_environment.sh
```

### 3. Install Dependencies
```bash
conda env create -f environment.yml
conda activate bigdata
```

### 4. Configure Spark
Update `config/spark_config.yaml` with your cluster settings:
```yaml
master: spark://master:7077
memory: 4g
cores: 4
```

## Usage

### Run the Complete Pipeline
```bash
python scripts/run_pipeline.py
```

### Run Individual Notebooks
```bash
jupyter notebook notebooks/1_data_ingestion.ipynb
```

### Monitor Performance
```bash
python scripts/performance_profiler.py
```

### Docker Deployment
```bash
docker build -t bigdata-pipeline .
docker run -it bigdata-pipeline
```

## Data Pipeline Steps

1. **Data Ingestion** (`1_data_ingestion.ipynb`)
   - Load data from multiple sources
   - Data validation and cleaning
   - Schema enforcement

2. **Feature Engineering** (`2_feature_engineering.ipynb`)
   - Feature creation and transformation
   - Feature scaling and normalization
   - Broadcast join implementation

3. **Model Training** (`3_model_training.ipynb`)
   - Train-test split
   - Hyperparameter tuning
   - Model selection and validation

4. **Evaluation** (`4_evaluation.ipynb`)
   - Performance metrics calculation
   - Visualization of results
   - Strong scaling analysis

## Configuration

### Spark Configuration (`config/spark_config.yaml`)
```yaml
spark:
  app_name: "BigData-Pipeline"
  master: "local[*]"
  executors: 4
  memory: "4g"
  cores: 8
```

### Tableau Configuration (`config/tableau_config.json`)
```json
{
  "server": "tableau.example.com",
  "port": 80,
  "database": "analytics_db",
  "refresh_schedule": "0 */6 * * *"
}
```

## Performance Monitoring

The `performance_profiler.py` script provides:
- CPU and Memory usage tracking
- Spark job execution time analysis
- Data processing throughput metrics
- Resource utilization reports

## Testing

Run the test suite:
```bash
python -m pytest tests/test_pipeline.py -v
```

## Tableau Dashboards

Access the Tableau dashboards for visual analytics:
- **Dashboard 1**: Data Ingestion Metrics
- **Dashboard 2**: Feature Engineering Analysis
- **Dashboard 3**: Model Training Progress
- **Dashboard 4**: Evaluation Results

See [Tableau Documentation](tableau/README_tableau.md) for details.

## Troubleshooting

### Spark Connection Issues
- Verify Spark installation: `spark-submit --version`
- Check `config/spark_config.yaml` settings
- Ensure Java is properly installed

### Memory Errors
- Increase executor memory in `spark_config.yaml`
- Reduce partition size in notebooks
- Monitor with `performance_profiler.py`

### Data Not Found
- Verify data paths in configuration files
- Check permissions on data directories
- Validate schema in `data/schemas/`

## Contributing

1. Create a feature branch
2. Make your changes
3. Run tests: `pytest tests/`
4. Submit a pull request

## License

MIT License - See LICENSE file for details

## Support

For issues and questions:
- Check the documentation in each notebook
- Review [Tableau README](tableau/README_tableau.md)
- Create an issue in the repository

## Version History

- **v1.0.0** (2026-02-28): Initial release
  - Data ingestion pipeline
  - Feature engineering module
  - ML model training framework
  - Evaluation and visualization tools

---

**Last Updated**: February 28, 2026
