"""
Performance Profiler Module
Monitors and profiles the Big Data pipeline execution
"""

import time
import psutil
import json
from datetime import datetime
from pyspark.sql import SparkSession
from typing import Dict, List, Tuple
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class PerformanceProfiler:
    """Track and analyze performance metrics during pipeline execution"""
    
    def __init__(self):
        self.metrics = {
            'cpu': [],
            'memory': [],
            'execution_time': [],
            'data_processed': 0,
            'jobs_completed': 0
        }
        self.start_time = None
        self.spark = None
    
    def initialize_spark(self, config_file: str = None):
        """Initialize Spark Session with configuration"""
        try:
            self.spark = SparkSession.builder \
                .appName("BigData-PerformanceProfiler") \
                .master("local[*]") \
                .getOrCreate()
            logger.info("Spark Session initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing Spark: {str(e)}")
            raise
    
    def start_profiling(self):
        """Start performance profiling"""
        self.start_time = time.time()
        logger.info("Performance profiling started")
    
    def get_cpu_usage(self) -> float:
        """Get current CPU usage percentage"""
        return psutil.cpu_percent(interval=1)
    
    def get_memory_usage(self) -> Dict[str, float]:
        """Get current memory usage"""
        memory = psutil.virtual_memory()
        return {
            'total_gb': memory.total / (1024**3),
            'used_gb': memory.used / (1024**3),
            'percent_used': memory.percent
        }
    
    def get_spark_metrics(self) -> Dict:
        """Get Spark application metrics"""
        if not self.spark:
            return {}
        
        try:
            sc = self.spark.sparkContext
            metrics = {
                'app_name': sc.appName,
                'executors': sc.defaultParallelism,
                'status': 'running'
            }
            return metrics
        except Exception as e:
            logger.warning(f"Error retrieving Spark metrics: {str(e)}")
            return {}
    
    def record_job_execution(self, job_name: str, execution_time: float, 
                            records_processed: int = 0):
        """Record execution metrics for a job"""
        self.metrics['execution_time'].append({
            'job': job_name,
            'time_seconds': execution_time,
            'timestamp': datetime.now().isoformat()
        })
        self.metrics['data_processed'] += records_processed
        self.metrics['jobs_completed'] += 1
        logger.info(f"Job '{job_name}' completed in {execution_time:.2f}s")
    
    def get_throughput(self) -> float:
        """Calculate data processing throughput (records/second)"""
        if self.start_time is None:
            return 0
        
        elapsed_time = time.time() - self.start_time
        if elapsed_time == 0:
            return 0
        
        return self.metrics['data_processed'] / elapsed_time
    
    def stop_profiling(self) -> Dict:
        """Stop profiling and return summary"""
        if self.start_time is None:
            logger.warning("Profiling was not started")
            return {}
        
        total_time = time.time() - self.start_time
        
        summary = {
            'total_execution_time_seconds': total_time,
            'total_data_processed': self.metrics['data_processed'],
            'jobs_completed': self.metrics['jobs_completed'],
            'throughput_records_per_sec': self.get_throughput(),
            'avg_memory_percent': sum(m['percent_used'] for m in self.metrics['memory']) / len(self.metrics['memory']) if self.metrics['memory'] else 0,
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info(f"Profiling completed. Total time: {total_time:.2f}s")
        return summary
    
    def periodic_monitoring(self, interval: int = 5):
        """Periodically monitor system metrics"""
        while True:
            try:
                cpu = self.get_cpu_usage()
                memory = self.get_memory_usage()
                
                self.metrics['cpu'].append({
                    'value': cpu,
                    'timestamp': datetime.now().isoformat()
                })
                self.metrics['memory'].append(memory)
                
                logger.debug(f"CPU: {cpu}% | Memory: {memory['percent_used']:.1f}%")
                time.sleep(interval)
            except KeyboardInterrupt:
                break
            except Exception as e:
                logger.error(f"Error in monitoring: {str(e)}")
    
    def export_metrics(self, output_file: str):
        """Export metrics to JSON file"""
        try:
            with open(output_file, 'w') as f:
                json.dump(self.metrics, f, indent=2, default=str)
            logger.info(f"Metrics exported to {output_file}")
        except Exception as e:
            logger.error(f"Error exporting metrics: {str(e)}")
    
    def generate_report(self) -> str:
        """Generate performance report"""
        report = []
        report.append("=" * 60)
        report.append("PERFORMANCE PROFILING REPORT")
        report.append("=" * 60)
        report.append(f"Jobs Completed: {self.metrics['jobs_completed']}")
        report.append(f"Total Data Processed: {self.metrics['data_processed']:,} records")
        report.append(f"Throughput: {self.get_throughput():.2f} records/sec")
        report.append(f"Execution Time Logs: {len(self.metrics['execution_time'])}")
        report.append("=" * 60)
        
        return "\n".join(report)


def main():
    """Main function for standalone profiling"""
    profiler = PerformanceProfiler()
    profiler.initialize_spark()
    profiler.start_profiling()
    
    # Example: Profile a sample job
    try:
        logger.info("Running sample job...")
        time.sleep(2)  # Simulate work
        profiler.record_job_execution("sample_job", 2.0, 10000)
        
        summary = profiler.stop_profiling()
        print(profiler.generate_report())
        print(json.dumps(summary, indent=2))
        
        profiler.export_metrics("performance_metrics.json")
    except Exception as e:
        logger.error(f"Error in main: {str(e)}")


if __name__ == "__main__":
    main()
